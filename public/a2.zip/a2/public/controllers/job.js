angular.module('MyApp')
  .controller('GroupCtrl', function($scope, $rootScope, $routeParams, Show, $modal, $resource, $http) {
      Show.get({ _id: $routeParams.id }, function(info) {

        $scope.group = info; 
      });

    $scope.animationsEnabled = true;

    $scope.rem = function(size) {
      var modalInstance = $modal.open({
        animation: $scope.animationsEnabled,
        templateUrl: 'remgroup.html',
        controller: 'bidCtrl',
        size: size,
        resolve: {
          group: function () {
            return $scope.group;
          }
        }
      });
    };

    $scope.open = function (size) {

      var modalInstance = $modal.open({
        animation: $scope.animationsEnabled,
        templateUrl: 'sendmail.html',
        controller: 'bidCtrl',
        size: size,
        resolve: {
          group: function () {
            return $scope.group;
          }
        }
      });

      modalInstance.result.then(function (selectedItem) {
        $scope.selected = selectedItem;
      });
    };


});