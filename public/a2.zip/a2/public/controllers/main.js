angular.module('MyApp')
  .controller('MainCtrl', function($scope, Show, $window, $modal, ResShow) {


    $scope.groups = Show.query();
    $scope.resumes = ResShow.query();

    $scope.filterByGenre = function(genre) {
      $scope.shows = Show.query({ genre: genre });
      $scope.headingTitle = genre;
    };
/*    $scope.filterByAlphabet = function(char) {
      $scope.shows = Show.query({ alphabet: char });
      $scope.headingTitle = char;
    };*/
       $scope.items = [
           'item1',
           'item2',
           'item3'
       ];
       $scope.addItem = function() {
           var newItemNo = $scope.items.length + 1;
           $scope.items.push('item' + newItemNo);
       };
      $scope.addresume = function (size) {

        var modalInstance = $modal.open({
          animation: $scope.animationsEnabled,
          templateUrl: 'newresume.html',
          controller: 'grpCtrl',
          size: size,
          resolve: {
            resume: function() {
              return $scope.resumes;
            }
          }
          });
      };

        $scope.addgroup = function (size) {

      var modalInstance = $modal.open({
        animation: $scope.animationsEnabled,
        templateUrl: 'newgroup.html',
        controller: 'grpCtrl',
        size: size,
        resolve: {
          resume: function() {
            return $scope.groups;
          }
        }
      });

      modalInstance.result.then(function (selectedItem) {
        $scope.selected = selectedItem;
      });
    };


      $scope.edit = function (__resumeID) {
        ResShow.get({ _id: __resumeID }, function(info) {
          $scope.resume = info; 

      var modalInstance = $modal.open({
        animation: $scope.animationsEnabled,
        templateUrl: 'editgroup.html',
        controller: 'grpCtrl',
        // size: size,
        resolve: {
          resume: function() {
            return $scope.resume;
          }, 
          resumeid: function() {
            return __resumeID;
          }
        }
      });
    });

      // modalInstance.result.then(function (selectedItem) {
      //   $scope.selected = selectedItem;
      // });
    };

      $scope.remove = function (__resumeID) {
        ResShow.get({ _id: __resumeID }, function(info) {
          $scope.resume = info; 

        var modalInstance = $modal.open({
          animation: $scope.animationsEnabled,
          templateUrl: 'remresume.html',
          controller: 'grpCtrl',
          resolve: {
            resume: function() {
              return $scope.resume;
            }
          }
      });

      // modalInstance.result.then(function (selectedItem) {
      //   $scope.selected = selectedItem;
      // });
    });
  };

       
  });