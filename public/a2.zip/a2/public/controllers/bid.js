angular.module('MyApp').controller('bidCtrl', function ($scope, $modalInstance,group, Send, Show, $window) {

  $scope.text = "متن نامه را وارد کنید : ";
  $scope.group = group;
  $scope.ok = function () {
    $scope.head = {
      group: $scope.group,
      text: $scope.text
    };
      Send.save($scope.head).$promise
      .then(function() {
        alert("نامه با موفقیت ارسال شد !");
      });
  };
  $scope.remove = function () {
    Show.delete({ _id : group._id}, function() {
       $window.location.href = '/';
    });
  };
  $scope.cancel = function () {
    $modalInstance.dismiss('cancel');
  };
});