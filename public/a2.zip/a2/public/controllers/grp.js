angular.module('MyApp').controller('grpCtrl', function ($scope, $modalInstance, Show, resume, ResShow, $routeParams, $window) {

  $scope.title = "نام گروه را وارد کنید : ...";
  $scope.mails = "ایمیل های مورد نظر را وارد کنید : ...";
  // $scope.mails = [];
  $scope.new = '';
  $scope.resume = resume;
  $scope.info = $scope.resume;


  $scope.ok = function () {
  $scope.head = {
    title: $scope.title, 
    mails: $scope.mails.split(',')
  };
  console.log($scope.head);
    Show.save($scope.head).$promise
      .then(function() {
        $window.location.href = '/';
      });
  };

  $scope.remove = function() {

    ResShow.delete({ _id : resume._id}, function() {
       $window.location.href = '/';
    });

  };

  $scope.add = function() {
    ResShow.save($scope.new).$promise
      .then(function() {
        $window.location.href = '/';
      });
  };

  $scope.edit = function(info) {
    ResShow.update(info).$promise
    .then(function() {
      $window.location.href = '/';
    });
  };


  $scope.cancel = function () {
    $modalInstance.dismiss('cancel');
  };
});