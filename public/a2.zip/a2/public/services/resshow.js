angular.module('MyApp')
  .factory('ResShow', function($resource) {
    return $resource('/api/v1/resumes/:_id', null, {
    	'update': {method:'PUT'}
    });
  });