angular.module('MyApp')
  .factory('Show', function($resource) {
    return $resource('/api/v1/groups/:_id', null , 
    	{
    		'update': {method:'PUT'}
    	});
  });