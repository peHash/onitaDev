angular.module('MyApp')
  .factory('Send', function($resource) {
    return $resource('/api/v1/send');
  });