var path = require('path');
var express = require('express');
var bodyParser = require('body-parser');

var crypto = require('crypto');
var bcrypt = require('bcryptjs');
var mongoose = require('mongoose');
var jwt = require('jwt-simple');
var moment = require('moment');

var async = require('async');
var request = require('request');

var sugar = require('sugar');
var nodemailer = require('nodemailer');
var _ = require('lodash');
var tokenSecret = 'your unique secret';

var Schema = mongoose.Schema,
    ObjectId = Schema.ObjectId;



var userSchema = new Schema({
  email: { type: String, unique: true, lowercase: true, trim: true },
  password: String
});

userSchema.pre('save', function(next) {
  var user = this;
  if (!user.isModified('password')) return next();
  bcrypt.genSalt(10, function(err, salt) {
    if (err) return next(err);
    bcrypt.hash(user.password, salt, function(err, hash) {
      if (err) return next(err);
      user.password = hash;
      next();
    });
  });
});

userSchema.methods.comparePassword = function(candidatePassword, cb) {
  bcrypt.compare(candidatePassword, this.password, function(err, isMatch) {
    if (err) return cb(err);
    cb(null, isMatch);
  });
};

var groupSchema = new Schema({
    id: ObjectId,
    title: String,
    emails: [String],
    msg:[String],
    sentAt: String
});

var resumeSchema = new Schema({
  id: ObjectId,
  name: String,
  desc: String
});

var User = mongoose.model('User', userSchema);

var Group = mongoose.model('Group', groupSchema);

var Resume = mongoose.model('Resume', resumeSchema);
/////////


mongoose.connect('mongodb://localhost/AA');




var app = express();

app.set('port', process.env.PORT || 9090);
app.use(bodyParser.json());
app.use(bodyParser.urlencoded({
  extended: true
}));
app.use(express.static(path.join(__dirname, 'public')));

function ensureAuthenticated(req, res, next) {
  if (req.headers.authorization) {
    var token = req.headers.authorization.split(' ')[1];
    try {
      var decoded = jwt.decode(token, tokenSecret);
      if (decoded.exp <= Date.now()) {
        res.send(400, 'Access token has expired');
      } else {
        req.user = decoded.user;
        return next();
      }
    } catch (err) {
      return res.send(500, 'Error parsing token');
    }
  } else {
    return res.send(401);
  }
}

function createJwtToken(user) {
  var payload = {
    user: user,
    iat: new Date().getTime(),
    exp: moment().add('days', 7).valueOf()
  };
  return jwt.encode(payload, tokenSecret);
}

app.post('/auth/signup', function(req, res, next) {
  var user = new User({
    firstName: req.body.firstName,
    lastName: req.body.lastName,
    cellPhoneNumber: req.body.cellPhoneNumber,
    email: req.body.email,
    password: req.body.password
  });
  user.save(function(err) {
    if (err) return next(err);
    res.send(200);
  });
});

app.post('/auth/login', function(req, res, next) {
  User.findOne({ email: req.body.email }, function(err, user) {
    if (!user) return res.send(401, 'User does not exist');
    user.comparePassword(req.body.password, function(err, isMatch) {
      if (!isMatch) return res.send(401, 'Invalid email and/or password');
      var cpUser = {
        email: user.email,
        password: user.password
      };
      var token = createJwtToken(cpUser);
      res.send({ token: token });
    });
  });
});


app.get('/api/v1/users', function(req, res, next) {
  if (!req.query.email) {
    return res.send(400, { message: 'Email parameter is required.' });
  }

  User.findOne({ email: req.query.email }, function(err, user) {
    if (err) return next(err);
    res.send({ available: !user });
  });
});



app.get('/api/v1/groups', function(req, res, next) {
  var query = Group.find();
      query.limit(40);
        query.exec(function(err, groups) {
          if (err) return next(err);
        res.send(groups);
        });
  });

app.get('/api/v1/groups/:id', function(req, res, next) {
    Group.findById(req.params.id, function(err, group) {
      if (err) return Next(err);
      res.send(group);
    });
});


app.post('/api/v1/groups', function (req, res, next) {

  var group = new Group({
      title: req.body.title,
      emails: req.body.mails
  });
  group.save(function(err) {
    if (err) return next(err);
    Group.findById(group, function (err, doc) {
    if (err) return handleError(err);
      console.log(doc);
    });
    res.send(200);
  });

});
app.delete('/api/v1/groups/:id', function(req, res, next) {
Group.findOne({ _id : req.params.id}, function (err, group) {
if (err) {
    console.log('Something Wrong Happened');
}
group.remove(function (err) {
    res.send(200);
});
});
});


app.get('/api/v1/resumes', function(req, res, next) {
  var query = Resume.find();
      query.limit(40);
        query.exec(function(err, resumes) {
          if (err) return next(err);
        res.send(resumes);
        });
  });

app.get('/api/v1/resumes/:id', function(req, res, next) {
    Resume.findById(req.params.id, function(err, resume) {
      if (err) return Next(err);
      res.send(resume);
    });
});

app.delete('/api/v1/resumes/:id', function(req, res, next) {
Resume.findOne({ _id : req.params.id}, function (err, model) {
if (err) {
    console.log('Something Wrong Happened');
}
model.remove(function (err) {
    res.send(200);
});
});
});


app.post('/api/v1/resumes', function (req, res, next) {

  var resume = new Resume({
      name: req.body.name, 
      desc: req.body.desc
  });
  resume.save(function(err) {
    if (err) return next(err);
    Resume.findById(resume, function (err, doc) {
    if (err) return handleError(err);
      console.log(doc); // { name: 'mongodb.org', _id: '50341373e894ad16347efe12' }
    });
    res.send(200);
  });

});

app.put('/api/v1/resumes', function (req, res, next) {
  
 
 Resume.findById(req.body._id, function(err, resume){
    if (err) return Next(err);
    console.log(resume);
    resume.name = req.body.name;
    resume.desc = req.body.desc;
    resume.save(function() {
      if (err) return Next(err);
      res.sendStatus(200);
    });
 });
});

app.post('/api/v1/send', function(req, res, next) {


var transporter = nodemailer.createTransport("SMTP", {
    service: "Gmail",
    auth: {
        user: "sec.lleiell.ret@gmail.com",
        pass: ""
    }
});
var mailOptions = {
    from: "Pe Hash ✔ <sec.lleiell.ret@gmail.com>", // sender address
    to: req.body.group.emails.join(','), // list of receivers
    subject: req.body.group.title, // Subject line
    html: req.body.text // plaintext body
};
transporter.sendMail(mailOptions, function(error, info){
    if(error){
        return console.log(error);
        res.sendStatus(400);
    }

    console.log('Message sent: ' + info.response);
Group.update({_id: req.body.group._id}, 
  {$push: {
    msg: req.body.text
  }}, {upsert: false}, function(err){
    if (err) return Next(err);
    res.sendStatus(200);
  });
});

});

app.get('*', function(req, res) {
  res.redirect('/#' + req.originalUrl);
});

app.use(function(err, req, res, next) {
  console.error(err.stack);
  res.send(500, { message: err.message });
});

app.listen(app.get('port'), function() {
  console.log('Express server listening on port ' + app.get('port'));
});
